from .connect_odoo import ConnectOdoo
from .models import load_env_vars
